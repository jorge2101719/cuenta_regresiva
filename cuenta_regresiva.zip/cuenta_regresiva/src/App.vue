<template>
    <div id="app">
        <h1>{{titular}}</h1>
        <input type="text" v-model="tempo">
        <button v-on:click="iniciar">Iniciar</button>
        <p id="mensaje"> Faltan {{ tempo }} segundo(s). {{aviso}} </p>
    </div>
</template>

<script>
export default {
    name: "App",
    data() {
        return {
            titular: 'Cuenta regresiva',
            tempo: '',
            aviso: ''
        }
    },
    methods: {
        iniciar: function(){
            setInterval(() => {
                if(this.tempo == 0 ){
                    this.aviso = 'Bien, el tiempo ha concluido. Gracias por jugar.'
                    clearInterval(iniciar);
                };
                this.tempo = this.tempo - 1;
            }, 1000);
        }
    },
}
</script>